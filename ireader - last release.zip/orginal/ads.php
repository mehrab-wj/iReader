﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>تعرفه ها</title>
<link rel="stylesheet" type="text/css" href="http://dl.20script.ir/blog/rozblog/01/style.css"/>
<link rel="stylesheet" type="text/css" href="style/style.css"/>
</head>

<style>
body {
	background: url('img/pad.png')#34495e;
	line-height: 1.7;
	font-size: 8pt;
	direction: rtl;
}

table{width: 600px;margin:50px auto;}
table tr td{background-color:#3498db;padding:4px;border-bottom:5px solid #0077aa;color:#fff;box-shadow:3px 0px 3px 0px rgba( 0, 0, 0, 0.3),0px -3px 3px 0px rgba( 0, 0, 0, 0.3);font:normal 16px Mj_Smooth;}
table thead tr td {text-align:center;color:#fff;background-color:#e74c3c;border-bottom:5px solid #c0392b;}
table tr.class td {background-color:#bf55ec;border-bottom:5px solid #8e44ad;}
a {color: white;}
a:hover {color: #B2EBF2;}
</style>
<body>
<p style="color:white;text-align:center;font-size:21px;">
	توجه : سیستم تبلیغاتی این سایت کاملا هوشمند و اتوماتیک بوده و تبلیغات شما
	بعد از پرداخت موفق ، به صورا کاملا خودکار در سایت ثبت میگردد !
</p>
<table cellpadding="0" cellspacing="0" >
<thead>
	<tr>
		<td Colspan="4"><label>تعرفه تبلیغات</label></td>
			</tr>
</thead>
	<tr class="class">
		<td><label>مکان تبلیغات</label></td>
		<td><label>هر 100 بازدید</label></td>
		<td>
			<label>
			هر 100 کلیک
		</label></td>
		<td><label>
			عملیات
		</label></td>
	</tr>

	<tr>
	<td class="forum-links"><label>تبلیغات متنی</label></td>
	<td>
		<label>3 هزار تومان</label>
	</td>
	<td>
		<label>18 هزار تومان</label>
	</td>
	<td>
		<a href="?plan=2">سفارش</a>
	</td>
	</tr>

	<tr class="class">
	<td class="forum-links"><label>طراحی بنر120*240</label></td>
	<td>
		<label>7 هزار تومان</label>
	</td>
	<td>
		<label>21 هزار تومان</label>
	</td>
	<td>
		<a href="?plan=3">سفارش</a>
	</td>
	</tr>

	<tr class="">
	<td class="forum-links"><label>تبلیغات 125*125</label></td>
	<td>
		<label>8 هزار تومان</label>
	</td>
	<td>
		<label>24 هزار تومان</label>
	</td>
	<td>
		<a href="?plan=4">سفارش</a>
	</td>
	</tr>

<tr class="class">
<td class="forum-links">
	<label>طراحی بنر 940**200
	</label></td>
<td>
	<label>10 هزار تومان</label>
</td>
<td>
	<label>30 هزار تومان<label>
</td>
<td>
	<a href="?plan=5">سفارش</a>
</td>
</tr>

<tr>
<td class="forum-links"><label>تبلیغات بین مطالب</label></td>
<td>
	<label>11 هزار تومان</label>
</td>
<td>
	<label>33 هزار تومان</label>
</td>
<td>
	<a href="?plan=6">سفارش</a>
</td>
</tr>

<tr class="class">
<td class="forum-links"><label>تبلیغات پاپ باکس</label></td>
<td>
	<label>16 هزار تومان</label>
</td>
<td>
	<label>48 هزار تومان</label>
</td>
<td>
	<a href="?plan=7">سفارش</a>
</td>
</tr>

</table>
</body>
</html>
